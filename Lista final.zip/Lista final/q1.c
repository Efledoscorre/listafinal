//nome do aluno: Lucas sabino assis
//matricula: UC22103214

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Aluno {
    char nome[50];
    int idade;
    float altura;
};

int main() {
	system("color f4");
    struct Aluno Dados;

    printf("digite o nome do aluno: ");
    scanf("%s", Dados.nome);

    printf("digite a idade do aluno: ");
    scanf("%d", &Dados.idade);

    printf("digite a altura do aluno: ");
    scanf("%f", &Dados.altura);

    
    printf("\ndados do Aluno:\n");
    printf("nome: %s\n", Dados.nome);
    printf("idade: %d\n", Dados.idade);
    printf("altura: %.2f\n", Dados.altura);

    return 0;
}

