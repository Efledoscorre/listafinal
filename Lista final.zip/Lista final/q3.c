//nome do aluno: Lucas sabino assis
//matricula: UC22103214

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

struct Produto {
    int codigo;
    char nome[50];
    char dataPublicacao[20];
};

void adicionarProduto(struct Produto listaProdutos[], int *quantidadeProdutos);
void listarProdutos(struct Produto listaProdutos[], int quantidadeProdutos);
void buscarProduto(struct Produto listaProdutos[], int quantidadeProdutos, const char *nome);

int main() {
    system("color f4");
	setlocale(LC_ALL, "Portuguese");
    struct Produto listaProdutos[50];
    int quantidadeProdutos = 0;
    int opcao;
    
    do {
        printf("\nMenu: \n");
        printf("1. adicionar Produto\n");
        printf("2. listar Todos os Produtos\n");
        printf("3. buscar por Nome\n");
        printf("4. sair\n");
        printf("escolha uma op��o: \n");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                adicionarProduto(listaProdutos, &quantidadeProdutos);
                break;
            case 2:
                listarProdutos(listaProdutos, quantidadeProdutos);
                break;
            case 3: {
                char nomeBusca[50];
                printf("digite o nome do produto para buscar: ");
                scanf("%s", nomeBusca);
                buscarProduto(listaProdutos, quantidadeProdutos, nomeBusca);
                break;
            }
            case 4:
                printf("encerrando o programa.\n");
                break;
            default:
                printf("op��o inv�lida. digite uma op��o valida.\n");
        }
    } while (opcao != 4);

    return 0;
}

void adicionarProduto(struct Produto listaProdutos[], int *quantidadeProdutos) {
    if (*quantidadeProdutos < 50) {
        printf("digite o c�digo do produto: ");
        scanf("%d", &listaProdutos[*quantidadeProdutos].codigo);

        printf("digite o nome do produto: ");
        scanf("%s", listaProdutos[*quantidadeProdutos].nome);

        printf("digite a data de publica��o do produto: ");
        scanf("%s", listaProdutos[*quantidadeProdutos].dataPublicacao);

        (*quantidadeProdutos)++;
        printf("produto adicionado\n");
    } else {
        printf("limite de produtos atingido. N�o � poss�vel adicionar mais.\n");
    }
}

void listarProdutos(struct Produto listaProdutos[], int quantidadeProdutos) {
    if (quantidadeProdutos > 0) {
        printf("\nlista de Produtos:\n");
        int i;
        for (i = 0; i < quantidadeProdutos; i++) {
            printf("c�digo: %d\nnome: %s\ndata de publica��o: %s\n", listaProdutos[i].codigo, listaProdutos[i].nome, listaProdutos[i].dataPublicacao);
        }
    } else {
        printf("nenhum produto cadastrado.\n");
    }
}

void buscarProduto(struct Produto listaProdutos[], int quantidadeProdutos, const char *nome) {
    int encontrado = 0;
    int i;
    for (i = 0; i < quantidadeProdutos; i++) {
        if (strcmp(listaProdutos[i].nome, nome) == 0) {
            printf("produto:\n");
            printf("c�digo: %d\nnome: %s\ndata de publica��o: %s\n", listaProdutos[i].codigo, listaProdutos[i].nome, listaProdutos[i].dataPublicacao);
            encontrado = 1;
            break;
        }
    }

    if (!encontrado) {
        printf("produto n�o encontrado.\n");
    }
}

